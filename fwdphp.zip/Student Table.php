
<?php
	 $host="localhost";
	 $dbuser="root";
	 $pass="root";
	 $dbname="online_exam";
	 $conn=mysqli_connect($host,$dbuser,$pass,$dbname);
		// echo "$conn";
		 if(mysqli_connect_errno())
		 {die("connection Failed!".mysqli_connect_error());
		 }
	?>
<html>
	<head>
		<Title> </title>
	</head>
		<body>
			<?php
				
				$sql="CREATE TABLE Student";
				$sql.="( USN int(5) Primary key ,";
				$sql.="Name varchar(20) Not Null,";
				$sql.="Email varchar(20) Not Null,";
				$sql.="Gender varchar(1) Not Null,";
				$sql.="Dob varchar(20) Not Null,";
				$sql.="Pass varchar(20) Not Null,";
				$sql.="Lastresult int(4) );";
				$res=mysqli_query($conn,$sql);
					echo "$res";
					if(!$res){
						die("query failed");
					}
					else{
						echo "Table Created Sucessfully";
					}
			?>
		
		</body>
</html>	

<?php
mysqli_close($conn);
?>