<?php
	 $host="localhost";
	 $dbuser="root";
	 $pass="root";
	 $dbname="online_exam";
	 $conn=mysqli_connect($host,$dbuser,$pass,$dbname);
		// echo "$conn";
		 if(mysqli_connect_errno())
		 {die("connection Failed!".mysqli_connect_error());
		 }
?>
<html>
	<head>
		<title>Listing</title>
	</head>
			<body>
				<?php
					$sql="SELECT * FROM questions ;"; //Q_no, Ques, Op_1, Op_2, Op_3, Op_4, Ans
					$res=mysqli_query($conn,$sql);
					//echo "$res";
					if(!$res){
						die("query failed".mysqli_error($conn));
					}
					else{
						$i=0;
						while($row=mysqli_fetch_array($res))
						{
							$question_array[$i]=$row['Ques'];
							$op_1_array[$i]=$row['Op_1'];
							$op_2_array[$i]=$row['Op_2'];
							$op_3_array[$i]=$row['Op_3'];
							$op_4_array[$i]=$row['Op_4'];
							$ans_array[$i]=$row['Ans'];
							$i++;
						}
						//echo "Table Created Sucessfully";
						$i=0;
					}     
				?>	 
				<table cellspacing="15px" border=0px">
          <form action="signup_destination.php" method="POST">
		  <tr>
          <td>Question:<?php echo $question_array[$i]; ?></td>
          </tr>
          <tr>
          
             <tr>
             <td>options</td>
                <td><input type="radio" name="q1" value="1" /><?php echo $op_1_array[$i]?><br />
					<input type="radio" name="q1" value="2" /><?php echo $op_2_array[$i]?><br />
					<input type="radio" name="q1" value="3" /><?php echo $op_3_array[$i]?><br />
					<input type="radio" name="q1" value="4" /><?php echo $op_4_array[$i]?></td><br />
             </tr>
            <tr> 
             
             </tr>
			 </tr>
			 <?php $i++; ?>
			 
			 <tr>
          <td>Question:<?php echo $question_array[$i]; ?></td>
          </tr>
          <tr>
          
             <tr>
             <td>options</td>
                <td><input type="radio" name="q2" value="1" /><?php echo $op_1_array[$i]?><br />
					<input type="radio" name="q2" value="2" /><?php echo $op_2_array[$i]?><br />
					<input type="radio" name="q2" value="3" /><?php echo $op_3_array[$i]?><br />
					<input type="radio" name="q2" value="4" /><?php echo $op_4_array[$i]?></td><br />
             </tr>
            <tr> 
             
             </tr>
			 </tr>
			 <?php $i++; ?>
			 
			 <tr>
          <td>Question:<?php echo $question_array[$i]; ?></td>
          </tr>
          <tr>
          
             <tr>
             <td>options</td>
                <td><input type="radio" name="q3" value="1" /><?php echo $op_1_array[$i]?><br />
					<input type="radio" name="q3" value="2" /><?php echo $op_2_array[$i]?><br />
					<input type="radio" name="q3" value="3" /><?php echo $op_3_array[$i]?><br />
					<input type="radio" name="q3" value="4" /><?php echo $op_4_array[$i]?></td>
             </tr>
            <tr> 
             <td><input type="submit" name="submit" value="submit"/></td>
             </tr>
			 </tr>
      </table>
			</body>	
</html>	

<?php
mysqli_close($conn);
?>			