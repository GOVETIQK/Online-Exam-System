<html>
     <head>
          <title>Question Entering </title>

     </head>
	 <?php
	  session_start();
			$ans1='English';
              echo "Enter the question for{$ans1}\n"; 
			 
echo $_SESSION['myValue']=$ans1;
			  ?>
			<form action="insert.php" method='POST'>
			  
			  Question:<input type="text" name="question" size="150" style="font-size:10pt;height:80px;width:900px;"><br>
			  Option1: <input type="text" name="op1" maxlength="20" size="20"><br>
			  Option2: <input type="text" name="op2" maxlength="20" size="20"><br>
			  Option3: <input type="text" name="op3" maxlength="20" size="20"><br>
			  Option4: <input type="text" name="op4" maxlength="20" size="20"><br>
			  Answer:<select name="ans">
               <option>Answer</option>
               <option>1</option>
               <option>2</option>
               <option>3</option>
               <option>4</option>
			   </select><br>
			  
			 
			  <input type="submit" name="submit" value="submit">
			  
</form>

	 </head>
	 
</html>	 