<?php
	 $host="localhost";
	 $dbuser="root";
	 $pass="root";
	 $dbname="online_exam";
	 $conn=mysqli_connect($host,$dbuser,$pass,$dbname);
		// echo "$conn";
		 if(mysqli_connect_errno())
		 {die("connection Failed!".mysqli_connect_error());
		 }
?>
<html>
	<head>
		<title>Deleting a question</title>
	</head>
			<body>
				<?php
						if($_POST['submit'])
						{
							// $USN=$_POST['USN'];
							$Q_no=$_POST['Q_no'];
							$course=$_POST['course'];
						}
						$sql="DELETE FROM questions WHERE Q_no='{$Q_no}'";
						//echo "{$sql}";
						$res=mysqli_query($conn,$sql);
						echo "$res";
					if(!$res){
						die("query failed");
					}
					else{
						echo "Question Deleted Sucessfully";
					}
					$sql="ALTER TABLE questions DROP Q_no;";
					$res=mysqli_query($conn,$sql);
					$sql="ALTER TABLE questions ADD (Q_no int(2) Auto_increment primary key)";
					$res=mysqli_query($conn,$sql);
				?>	 
			</body>	
</html>	

<?php
mysqli_close($conn);
?>			