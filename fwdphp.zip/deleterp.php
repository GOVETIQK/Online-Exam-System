<html>
	<head>
		<title>Deleting a question</title>
	</head>
			<body>
				<form action="deleteq.php" method="POST">
				    Enter the question no and the coures which is to be deleted from the data base<br>
                    Question_no:<input type="text" name="Q_no" maxlength="20" size="20"><br>
					course:<input type="text" name="course" maxlength="20" size="20"><br>
				 <td><input type="submit" name="submit" value="Delete"/></td>	 
			</body>	
</html>	

			