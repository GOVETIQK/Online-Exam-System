<?php
	 $host="localhost";
	 $dbuser="root";
	 $pass="root";
	 $dbname="online_exam";
	 $conn=mysqli_connect($host,$dbuser,$pass,$dbname);
		// echo "$conn";
		 if(mysqli_connect_errno())
		 {die("connection Failed!".mysqli_connect_error());
		 }
?>
<html>
	<head>
		<title>Sign up Page</title>
	</head>
			<body>
				<?php
				     if($_POST['submit'])
					 {   $USN=$_POST['USN'];
						 $first=$_POST['first_name'];
						 $last=$_POST['last_name'];
						 $email=$_POST['email'];
						 $year=$_POST['year'];
						 $month=$_POST['month'];
						 $gender=$_POST['gender'];
						 $pass=$_POST['pass'];
						 $day=$_POST['day'];
						 $dob=$year.'/'.$month.'/'.$day;
						 $name=$first.' '.$last;
						 $repass=$_POST['repass'];
						 echo "$USN\n";
						 if(empty($USN)||empty($first)||empty($email)||empty($day)||empty($month)||empty($year)||empty($gender)||empty($pass)||empty($repass))
						 { echo"OOPs! Your are suppose to not leave any of the constrains empty ";}
					     elseif($pass!=$repass)
						 { echo "Pass word does not match";}
						 else
						 {
							 $sql="INSERT INTO Student".
									"(USN,Name,Email,Gender,Dob,Pass)".
									"VALUES($USN,'{$name}','{$email}','{$gender}','{$dob}','{$pass}');";
								
				
							$res=mysqli_query($conn,$sql);
								echo "$res";
								if(!$res){
									die("query failed".mysqli_error($conn));
								}
								else{
									echo "Data Inserted Sucessfully";
								}
									 }
					 }
				?>	 
			</body>	
</html>	

<?php
mysqli_close($conn);
?>			