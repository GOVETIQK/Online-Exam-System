<html>
     <head>
          <title>Signup Page </title>

     </head>
     <body background="http://cdn.wallpapersafari.com/68/92/P3cioG.jpg" text="white">
          <table cellspacing="15px" border=0px">
          <form action="signup_destination.php" method="POST">
		  <tr>
          <td>USN</td>
          <td><input type ="text" name="USN" /></td>
          </tr>
          <tr>
          <tr>
          <td>First name</td>
          <td><input type ="text" name="first_name" /></td>
          </tr>
          <tr>
          <td>Last name</td>
          <td><input type ="text" name="last_name" /></td>
          </tr>
          <tr>
          <td>Email</td>
          <td><input type ="text" name="email" /></td>
          </tr>
          <tr>
          <td>Date of Birth</td>
          <td><select name="year">
               <option>Year</option>
               <option>1995</option>
               <option>1996</option>
               <option>1997</option>
               <option>1998</option>
               <option>1999</option>
             </select> 
             <select name="month">
               <option>month</option>
               <option>1</option>
               <option>2</option>
               <option>3</option>
               <option>4</option>
               <option>5</option>
               <option>6</option>
               <option>7</option>
               <option>8</option>
               <option>9</option>
               <option>10</option>
               <option>11</option>
               <option>12</option>
             </select>
             <select name="day">
               <option>day</option>
               <option>1</option>
               <option>2</option>
               <option>3</option>
               <option>4</option>
               <option>5</option>
               <option>6</option>
               <option>7</option>
               <option>8</option>
               <option>9</option>
               <option>10</option>
               <option>11</option>
               <option>12</option>
               <option>13</option>
               <option>14</option>
               <option>15</option>
               <option>16</option>
               <option>17</option>
               <option>18</option>
               <option>19</option>
               <option>20</option>
               <option>21</option>
               <option>22</option>
               <option>23</option>
               <option>24</option>
               <option>25</option>
               <option>26</option>
               <option>27</option>
               <option>28</option>
               <option>29</option>
               <option>30</option>
               <option>31</option>
             </select></td>
             </tr>
             <tr>
             <td>Gender</td>
                <td><input type="radio" name="gender" value="M" />Male
                    <input type="radio" name="gender" value="F" />Female</td>
             </tr>
             <tr>
             <td>Password</td>
             <td><input type="password" name="pass" /></td>
             </tr>
             <td>Retype Password</td>
             <td><input type="password" name="repass" /></td>
             </tr>
             <td><input type="submit" name="submit" value="submit"/></td>
             </tr>
      </table>
     <body>
</html>