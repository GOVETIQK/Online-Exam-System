<?php
	 $host="localhost";
	 $dbuser="root";
	 $pass="root";
	 $dbname="online_exam";
	 $conn=mysqli_connect($host,$dbuser,$pass,$dbname);
		// echo "$conn";
		 if(mysqli_connect_errno())
		 {die("connection Failed!".mysqli_connect_error());
		 }
?>
<html>
	<head>
		<title>Listing</title>
	</head>
			<body>
				<?php
					$sql="SELECT * FROM questions ;"; //Q_no, Ques, Op_1, Op_2, Op_3, Op_4, Ans
					$res=mysqli_query($conn,$sql);
					//echo "$res";
					if(!$res){
						die("query failed".mysqli_error($conn));
					}
					else{
						while($row=mysqli_fetch_array($res))
						{
							echo"Q_no:{$row['Q_no']}<br>".
							"QUESTION:{$row['Ques']}<br>".
							"OPTION 1:{$row['Op_1']}<br>".
							"OPTION 2:{$row['Op_2']}<br>".
							"OPTION 3:{$row['Op_3']}<br>".
							"OPTION 4:{$row['Op_4']}<br>".
							"ANSWER is option no :'{$row['Ans']}'<br>".
							"-----------------------------------------------------------";
						}
						//echo "Table Created Sucessfully";
					}
					
					 
				     
				?>	 
			</body>	
</html>	

<?php
mysqli_close($conn);
?>			