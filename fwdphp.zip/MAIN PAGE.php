<html>
     <head>
          <title>Signup Page </title>

     </head>
     <body background="http://www.pixelstalk.net/wp-content/uploads/2016/05/Gaming-Wallpapers-Desktop-Photo.jpg" text="white">
	 <h1>ONLINE EXAMINATION</h1> 
          <table cellspacing="15px" border=0px" align="center">
          
          <tr></tr>
          <tr></tr>
          <tr></tr>
          <tr></tr>
          <tr></tr>
          <tr></tr>
          <tr></tr>
          <tr></tr>
          <tr></tr>
          <tr></tr>
          <tr></tr>
          <tr></tr>
          <tr></tr>
          <tr></tr>
          <tr></tr>
		  <form method="get" action="signup_sourceS.php">
           <tr>
          <td><h1><input type="submit" name="submit" value="STUDENT SIGNIN"/></h1></td>  <br />
          </tr>
		  </form>
		  <form method="get" action="">
          <tr>
          <td><h1><input type="submit" name="TEACHER_LOGIN" value="TEACHER LOGIN"/></h1></td>    
          </tr>
          <tr>
          <td><h1><input type="submit" name="ADMIN_LOGIN" value="ADMIN'S   LOGIN"/></h1></td>    
          </tr>
      </table>
     <body>
</html>