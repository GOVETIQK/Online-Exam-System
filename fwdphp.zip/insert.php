
<?php
	 $host="localhost";
	 $dbuser="root";
	 $pass="root";
	 $dbname="online_exam";
	 $conn=mysqli_connect($host,$dbuser,$pass,$dbname);
		// echo "$conn";
		 if(mysqli_connect_errno())
		 {die("connection Failed!".mysqli_connect_error());
		 }
	?>
<html>
	<head>
		<Title> </title>
	</head>
		<body>
			<?php
				session_start();
				//$_SESSION['myValue']=$ans1;
                 echo $_SESSION['myValue'];
				$tec=$_SESSION;
				session_destroy();
				if($_POST['submit'])
				{
					$question=$_POST['question'];
					$op1=$_POST['op1'];
					$op2=$_POST['op2'];
					$op3=$_POST['op3'];
					$op4=$_POST['op4'];
					$ans=$_POST['ans'];
					//$ans1=$_POST['ans1'];
					//echo "{$ans1}";
					
					if(empty($question)||empty($op1)||empty($op2)||empty($op3)||empty($op3)||empty($op4)||empty($ans))
					{
						echo"OOPs! Your are suppose to not leave any of the constrains empty ";
					}
				else{
			
				
						$sql="INSERT INTO questions".
							"(Ques,Op_1,Op_2,Op_3,Op_4,Ans)".
							"VALUES('{$question}','{$op1}','{$op2}','{$op3}','{$op4}','{$ans}');";
						
						$res=mysqli_query($conn,$sql);
							echo "$res";
						   if(!$res){
										die("query failed".mysqli_error($conn));
									}
							else{
									echo "Question inserted sucessfully";
								}
				    }	
				}	
			?>
		
		</body>
</html>	

<?php
mysqli_close($conn);
?>